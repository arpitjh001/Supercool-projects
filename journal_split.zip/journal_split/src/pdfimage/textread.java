package pdfimage;
//This class extracts the application no. and pageno. from pdf and make filename from it 
import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class textread extends split_and_conquer{

   public String reading(File file) throws IOException {   //for getting application no. and pageno.
	  Pattern pat = Pattern.compile("(Class\\s\\d*)\\s*(\\.*|\\w*.*|\\d*.*)\\s*.*\\s*\\s(\\d{6,})\\s*(\\d+[/]\\d+[/]\\d+)"); 
	  Pattern pat1 = Pattern.compile("\\d+$");
	  String appl = "";
	  String clas = "";
	  String page = "";
      PDDocument document = PDDocument.load(file);
      PDFTextStripper pdfStripper = new PDFTextStripper();

      //Retrieving text from PDF document
      String text = pdfStripper.getText(document);
      Matcher matcher = pat.matcher(text);
      Matcher matcher1 = pat1.matcher(text);
      
      if(matcher1.find()) {
       page = matcher1.group(0); 
      }
      
      if(matcher.find()) {
       clas = matcher.group(1);
       clas = clas.replaceAll("\\s+","");
       appl = matcher.group(3);	 
       appl = appl.replaceAll("\\s*\\W","");     //remove all spaces and non-words
       appl = page+"_"+clas+"_"+appl;  //filename will be pageno_class_application no.
      }
      
        else 
        { appl = page+"_"+"useless";
          appl = appl.replaceAll("\\s*","");
    	  //System.out.println(text); //exceptional cases
        }  
      
      document.close();
      return appl;
   } 
     
 }
   