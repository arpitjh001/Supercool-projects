package pdfimage;
//This class is used for opening a image extraction tool (xpdf)
import java.io.*;
public class command extends split_and_conquer {

     public void commandtool(File file,BufferedWriter bw,String pdffilename) throws Exception {  //creating batch file
    	 String file_path = file.getAbsolutePath();
    	 //bw.write("pdftohtml -f 1 -l 1 "+file_path+"\\"+pdffilename+" "+file_path+"\\html \n");
    	 bw.write("pdfimages "+file_path+"\\"+pdffilename+" "+file_path+"\\");
	     bw.newLine();
	     pdffilename = pdffilename.replaceAll(".pdf","");
	     bw.write("convert "+file_path+"\\-0000.ppm "+file_path+"\\"+pdffilename+".jpg");
	     bw.newLine();
	     bw.write("del "+file_path+"\\-0000.ppm ");
	     bw.newLine();
	     bw.newLine();
     }	 
    
     public void executebatch(String batchfile) {	 //executing batch file
    	 Runtime runtime = Runtime.getRuntime();
         try {
        	 runtime.exec("cmd /c start  "+batchfile);        
             } 
         catch(IOException ioException) {
              System.out.println(ioException.getMessage());
            }    	   
        }    
 }