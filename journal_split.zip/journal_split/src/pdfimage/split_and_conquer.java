package pdfimage;

import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.io.BufferedWriter;
import java.io.File;

public class split_and_conquer {
	public static void main(String[] args) throws Exception {
	  //location_chooser l = new location_chooser();
	  //String location = l.get_loc();
	 String location = "C:\\Users\\welcome\\Desktop\\pdf"; //for testing
	 File files[] = finder(location);

	 for (File fi : files) {
		 
	  System.out.println("Working on file :"+fi);
	  String fil = fi.toString().replaceAll("\\s","").replaceAll("\\(","_").replaceAll("\\)","");
      File newFile = new File(fil);
      if(fi.renameTo(newFile)){
          System.out.println("File rename success");;
      }else{
          System.out.println("File rename failed");
      }
	  
	  System.out.println("Splitting up the pdf file.....");
	  splitpdf gpi = new splitpdf();	//splitting up the pdf
	  gpi.execute(newFile); //getting directory location where the splitted pdfs are saved
	  
	  System.out.println("Renaming the pdf files(page no_appl.no_jour.no)......");
	  split_and_conquer sc = new split_and_conquer();
	  String foldername  = newFile.getName().replaceAll(".pdf","");
	  List<String> foldernames = sc.File_renaming(location,foldername); //renaming files
	  
	  System.out.println("Removing Useless pages and merging multispan pdfs.....");
	  removing_useless ru = new removing_useless();
	  List<File> pdffolders = ru.remove_merge(location+"\\"+foldername);
	  
	  System.out.println("Renaming done!\nNow creating batch file......");
	  
	  BufferedWriter bw = null;
      FileWriter fw = null;
      String batchfile  = location+"\\"+foldername+"\\createhtml.bat";
      fw = new FileWriter(batchfile);
      bw = new BufferedWriter(fw);
      bw.write("cd C:\\Users\\welcome\\Desktop"+"\n"); //location of pdftohtml.exe file
	  Iterator<File> itr= pdffolders.iterator();
	  command c = new command();
	  
	  while(itr.hasNext()) {
	    String filename = itr.next().toString();
	    File file = new File(filename);
	    File pdffiles[] = finder(filename);
	    String pdffilename = pdffiles[0].getName();
	    c.commandtool(file,bw,pdffilename);
	  }

	  bw.write("exit");
	  bw.flush();
	  bw.close();
	  fw.close();
	  System.out.println("Batch File Created!\nNow Extracting images and Creating html files......");
	  System.out.println("Batch File = "+batchfile);
	  //c.executebatch(batchfile);  
	 }	
   }  
	
  public List<String> File_renaming(String location,String name) throws IOException { 
	  List<String> foldernames = new ArrayList<>(); 
	    File []folder = new File(location+"\\"+name).listFiles();
	      for (File file : folder) {
	          String pdffilename = file.toString()+"\\"+file.getName()+".pdf";
		      textread tr  = new textread(); //for extracting filename from pdfs
			  Renaming fr = new Renaming();  //for renaming files
			  File f = new File( pdffilename);
			  foldernames.add(f.getParent().toString());
			  String file_loc = file.toString();
			  String appl = tr.reading(f);
			  String journal = fr.get_journal(pdffilename);//getting journal no.
	          file = fr.file_rename(appl,journal,f,file_loc); //renaming files
	      }
	      return foldernames;
  } 
	
  public static File[] finder( String location){
        File dir = new File(location);
        return dir.listFiles(new FilenameFilter() { 
                 public boolean accept(File dir, String filename)
                      { return filename.endsWith(".pdf"); }
        } );
  }		
}
