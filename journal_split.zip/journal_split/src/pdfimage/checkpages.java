package pdfimage;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class checkpages {
	public static void main(String []args) throws java.lang.NullPointerException,java.lang.IllegalStateException{
	 
	try{
		File file = new File("C:\\Users\\welcome\\Desktop\\test.txt");
		File outfile = new File("C:\\Users\\welcome\\Desktop\\t.txt");
		FileOutputStream fos = new FileOutputStream(outfile);
		checkpages cp = new checkpages();
		int start_page = cp.maketxt(file,fos);
		//System.out.println("start page : "+start_page);
		splitpdf sp = new splitpdf();
		//sp.execute(location,start_page,outfile);
		sp.rename_image(outfile,start_page);
	   }
	catch(Exception e){
		e.printStackTrace();
	   }
 
	}
	public int maketxt(File file,FileOutputStream fos)
	{int start_page = 0;
	int tot = 0;
	Pattern pat = Pattern.compile("(\\d+\\s+)(Trade Marks Journal No\\s*:)\\s*(\\d+)");
	Pattern pat2 = Pattern.compile("(Class\\s*\\d*)\\s*.*\\s*.*\\s*\\d*\\s*\\d+[/]\\d+[/]\\d+");
	Pattern pat3 = Pattern.compile("Class\\d{8}|Class\\d{1,2}(AdvertisedbeforeAcceptanceundersecti)");
	Scanner scan = null;
	Scanner start_page_scan = null;
	try{
		
	//File file = new File("C:\\Users\\welcome\\Desktop\\test1.txt");	
	//File file = new File(args[0]);
	scan = new Scanner(file);
	start_page_scan = new Scanner(file);  //for first pageno scanning
	//args[1] = args[0]+"output";
   
	DataOutputStream dataOut = new DataOutputStream(fos);
	//-------------------------------------------------------------------------------------------------------------------
	String pageno = " ";
	String start_p = " ";
	
	int page = 0;
	int check=0;
	String appl = " ";
	long start = System.nanoTime();
	appl = scan.findWithinHorizon(pat2,0);
	pageno = scan.findWithinHorizon(pat,0);
	
	Matcher match = pat.matcher(pageno);
	Matcher match2 = pat2.matcher(appl);
	
	start_p = start_page_scan.findWithinHorizon(pat,0); //for getting the start page
	Matcher match_start = pat.matcher(start_p);        //again matching pattern for group extraction 
	if(match_start.find()) {               
	start_p = match_start.group(1);
	start_p = start_p.replaceAll("\\s+\\f+",""); 
	start_page = Integer.parseInt(start_p); } 
	
	if(match2.find()) {                         //for first page
	   appl = match2.group(0);
	   appl = appl.replaceAll("Class\\s*\\d*|\\r|\\n|Advertised .*Proviso",""); //removing class no,newline char,Advertised...
		}
	if(match.find()) {
	  pageno = match.group(1);
	  pageno = pageno.replaceAll("\\s+\\f+",""); 
	  page =  Integer.parseInt(pageno);
	  }

	dataOut.writeBytes(page+" "+appl+"\r\n");
	//System.out.print(pageno+" "+appl+"\n");
	      
	while (pageno != null)
	 {   
		    appl = scan.findWithinHorizon(pat2,0);
	        pageno = scan.findWithinHorizon(pat,0);
	        
	        if(pageno == null) { break;}
	        Matcher matcher = pat.matcher(pageno);
	        if(appl == null) {continue;}
	        Matcher matcher2 = pat2.matcher(appl);
	        if(matcher.find()) {                     //for page no. extraction
	        	pageno = matcher.group(1);
	        	pageno = pageno.replaceAll("\\s+\\f+",""); 
	        	}
	    	if(matcher2.find()) {                 //for application no.
	    		 appl = matcher2.group(0);
	    		 appl = appl.replaceAll("Class\\s*\\d*|\\r|\\n|Advertised .*Proviso","");
	    		 Matcher match3 = pat3.matcher(appl);
	    		 if(match3.find()) {      //for image trademarks
	    			 appl = "image_"+appl; 
	    		 }
	    		 check = 1;
	         }
	    	else { 
	    	       appl = matcher2.group(0);
	    		   check = 0;
	    	      }
	    		 
	    	if(check==1) {
	        page =  Integer.parseInt(pageno);
	    	dataOut.writeBytes(page+" "+appl+"\r\n");
	        //System.out.print(page+" "+appl+"\n"); 
	        } 
	    	else {
	    	continue; }
	        
	    	tot++;
	  } 
	      //appl = appl.replaceAll("\\s+","");    //for last page
	      appl = appl.replaceAll("Class\\s*\\d*","");
 		  appl = appl.replaceAll("\\r|\\n", "").replaceAll("Advertised .*Proviso","");
	      dataOut.writeBytes(++page+" "+appl+"\r\n");
	      //System.out.print(page+" "+appl+"\n");
	      dataOut.close();
	      long dur = (System.nanoTime()-start)/1000000;
	      System.out.println("Results found: " + tot+" in "+dur+" msecs");	      
	      
	}
	catch(Exception e){
	e.printStackTrace();
	}
	finally{
	scan.close();
	}  
	return start_page;
  }
	
}
//for checking if pageno corresponds to an image use regex ("(\d+) ('|!|@|#|$|%|^|&|\*|\[|\]|~|`)*\d{5,7}\s*\d{1,2}[/]\d{1,2}[/]\d{4}"),if it returns something then its an image
//for renaming images use group(1) from above regex for extracting application name
//for extracting pageno line by line use regex(^\d+)

