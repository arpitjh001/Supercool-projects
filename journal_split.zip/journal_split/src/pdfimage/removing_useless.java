package pdfimage;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;

public class removing_useless {
public List<File> remove_merge(String pdffolder) throws InvalidPasswordException, IOException {
	File file = new File(pdffolder); 
	String path  = file.toString();
	List<File> pdffiles = getpdffile(path);
	Iterator<File> itr= pdffiles.iterator();
	File first = itr.next();
	File sample1  = first;
	File second;
	while(itr.hasNext()) {
      second = itr.next();
      first = compare(first,second);
	}
	check_delete(sample1);
	List<File> folders  = getpdffolder(pdffolder);
	return folders;
 }

public static void check_delete(File sample1) {
	String s = sample1.getName();
	String wordToFind = "useless";
	Pattern word = Pattern.compile(wordToFind);
	Matcher match = word.matcher(s);
	if (match.find()) {
		File sample = new File(sample1.getParent());
		deleteDir(sample);	
	}
}

public static File compare(File first,File second) throws InvalidPasswordException, IOException {
	String s = second.getName();
	String wordToFind = "useless";
	Pattern word = Pattern.compile(wordToFind);
	Matcher match = word.matcher(s);
	if (match.find()) {
	  //System.out.println(first.getName()+","+second.getName());	
	  merge(first,second);
	}
	else {
		first = second;
	}
  return first;	
}

@SuppressWarnings("deprecation")
public static void merge(File first,File second) throws InvalidPasswordException, IOException {
    PDDocument doc1 = PDDocument.load(first);
    PDDocument doc2 = PDDocument.load(second);
    PDFMergerUtility PDFmerger = new PDFMergerUtility();
    PDFmerger.setDestinationFileName(first.getPath());
    PDFmerger.addSource(first);
    PDFmerger.addSource(second);
    PDFmerger.mergeDocuments();
    doc1.close();
    doc2.close();
    String sec = second.getParent();
    File file = new File(sec);
    deleteDir(file);
  }

public static boolean deleteDir(File dir) {
    if (dir.isDirectory()) {
       String[] children = dir.list();
       for (int i = 0; i < children.length; i++) {
          boolean success = deleteDir (new File(dir, children[i]));
          
          if (!success) {
             return false;
          }
       }
    }
    return dir.delete();
 }

public static List<File> getpdffile(String path) {
	List<File> pdffiles = new ArrayList<>();
	File []folder = new File(path).listFiles();
    int tot_folders = folder.length;
    for(int i=1;i<tot_folders;i++) {
      File dir = new File(path+"\\sample"+i);
      boolean exists = dir.exists();
      if(exists) {
       File []pdfs = finder(path+"\\sample"+i);
       pdffiles.add(pdfs[0]);
      }	
	} 
    return pdffiles;
}	

 public static List<File> getpdffolder(String loc) {
	 List<File> pdffolder = new ArrayList<>(); 
	 {
	 File[] files = new File(loc).listFiles(new FileFilter() {
	 @Override
	 public boolean accept(File f) {
	   if(f.isDirectory()) {
		   pdffolder.add(f);
	    }
	   return f.isDirectory();
	  }
	 });
   }
	 return pdffolder;
  }
 
 public static File[] finder( String location){
     File dir = new File(location);
     return dir.listFiles(new FilenameFilter() { 
              public boolean accept(File dir, String filename)
                   { return filename.endsWith(".pdf"); }
     } );
}		
}
