package pdfimage;
import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.util.regex.Matcher;

public class Renaming extends split_and_conquer {
	public File file_rename(String appl,String journal,File file,String location) throws IOException {
          String filename = appl+"_"+journal+".pdf";
          filename = filename.replaceAll("\\s*","");
		  filename = location+"\\"+filename;
		  File newName = new File(filename);
      	  file.renameTo(newName);
          return file;	            

	}
	public String get_journal(String f) throws IOException {
		 File file  = new File(f);  
		 String journal = "";
		  //String date = "";
		  Pattern pat = Pattern.compile("(?!Journal No:)\\s*(\\d+)\\s*,*\\s*(\\d+[/]\\d+[/]\\d+)"); //for folder renaming
		  PDDocument document = PDDocument.load(file);
	      PDFTextStripper pdfStripper = new PDFTextStripper();
	      //Retrieving text from PDF document
	      String text = pdfStripper.getText(document);
	      Matcher matcher = pat.matcher(text);
	      if(matcher.find()) {
	       journal = matcher.group(0);	  
	       journal = journal.replaceAll("\\s*,\\s*",""); //remove all spaces and comma
	       journal = journal.substring(0,journal.length()-10);
	      }
	      else journal = "journal";
	       document.close();
          return journal;	            

	}
} 
	      
	    

