package pdfimage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;
import java.io.IOException;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.multipdf.Splitter;

public class splitpdf {

	public void execute(File file) {
	    //File inputFile = new File("C:\\Users\\welcome\\Desktop\\pdf\\test2.pdf");
		File inputFile = file;
	    File currentPath = new File(file.getParent());
	    String folder= currentPath.getName();
	    folder = currentPath.getParent()+"\\"+folder+"\\"+file.getName().replaceAll(".pdf","");
        File dir = new File(folder);
        dir.mkdir();
	    PDDocument document = null;
	    try {
	        document = PDDocument.load(inputFile);
	        int start = 1;              //start and end denotes the index(pageno) of pdf
	        int end = 1;
	        int batchSize = 50;
	        int finalBatchSize = document.getNumberOfPages() % batchSize;
	        int noOfBatches = document.getNumberOfPages() / batchSize;
	        for (int i = 1; i <= noOfBatches; i++) {
	            start = end;
	            end = start + batchSize;
	            System.out.println("Batch: " + i + " start: " + start + " end: " + end);
	            splitted(dir,document, start, end);
	        }
	        // handling the remaining
	        start = end;
	        end += finalBatchSize;
	        System.out.println("Final Batch  start: " + start + " end: " + end);
	        splitted(dir,document, start, end);
	        document.close();

	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        //close the document
	    }	   
	}

	private void splitted(File dir,PDDocument document, int start, int end) throws IOException {
        
	    Splitter splitter = new Splitter();
	    splitter.setStartPage(start);  //sets the starting page from where the read begins
	    splitter.setEndPage(end);
	    List<PDDocument> splittedDocuments = splitter.split(document);
        int i = start;
        
	    for (int index = 0; index < splittedDocuments.size(); index++) {
	        PDDocument splittedDocument = splittedDocuments.get(index);
		    splittedDocument.setDocumentInformation(document.getDocumentInformation());
	    	splittedDocument.getDocumentCatalog().setViewerPreferences(document.getDocumentCatalog().getViewerPreferences());
	    	new File(dir+"\\sample"+i).mkdir();
	    	splittedDocument.save(dir +"\\sample"+i+"\\sample"+ i +".pdf");
		    ++i;
	    	//System.out.println(++i + " PDF�s created");
		    splittedDocument.close();
	    }
		     
      }
	
	public void rename_image(File outfile,int start_page) {
		BufferedReader br = null;
		FileReader fr = null;
		Pattern pat1 = Pattern.compile("(\\d+) ('|!|@|#|$|%|^|&|\\*|\\[|\\]|~|`)*(\\d{5,7})\\s*\\d{1,2}[/]\\d{1,2}[/]\\d{4}"); //image
		Pattern pat = Pattern.compile("^\\d+");
		String name = "";
		int i=1;
		int pageno = 0;
		try {
			fr = new FileReader(outfile);
			br = new BufferedReader(fr);
			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				Matcher match = pat.matcher(sCurrentLine);
				if(match.find()) {
				pageno = Integer.parseInt(match.group(0));
				System.out.println(pageno); 
                Matcher match1 = pat1.matcher(sCurrentLine);
      		    if(match1.find()) {
      				  //rename image	
      		    	name = match.group(3);
      		    	File oldName = new File("C:\\xpdf-tools-win-4.00\\xpdf-tools-win-4.00\\bin32\\t-000"+i+".ppm");
      		    	File newName = new File("C:\\xpdf-tools-win-4.00\\xpdf-tools-win-4.00\\bin32\\"+name+".ppm");
      		    	oldName.renameTo(newName);
      		    	i++;
      		     }
      		    else continue; 					
			   }
			  }
            } catch (IOException e) {
			    e.printStackTrace();
		    } 
	finally {
			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			   } catch (IOException ex) {
				ex.printStackTrace();
               }		
	       }
		 
		 /*Splitter splitter = new Splitter();
		 splitter.setStartPage(11);  //sets the starting page from where the read begins
		 splitter.setEndPage(15);
		 File inputFile = new File("C:\\Users\\welcome\\Desktop\\test1.pdf");
		 try {
		 PDDocument document = document = PDDocument.load(inputFile);
		 List<PDDocument> splittedDocuments = splitter.split(document);
		 document.save(new File("C:\\Users\\welcome\\Desktop\\testing.pdf"));
		 Iterator<PDDocument> iterator = splittedDocuments.listIterator();
		 int i = 1;
		 PDFMergerUtility PDFmerger = new PDFMergerUtility();
		 PDFmerger.setDestinationFileName("C:/PdfBox_Examples/data1/merged.pdf");
	      while(iterator.hasNext()) {
	         PDDocument pd = iterator.next();
	         pd = iterator.next();
	         //adding the source files
	         PDFmerger.addSource(file1);
	         PDFmerger.addSource(file2);

	         //Merging the two documents
	         PDFmerger.mergeDocuments(null);
	      } 


		 } 
		 catch (IOException e) {
		        e.printStackTrace();
		    } finally {
		        //close the document
		    }	*/
   }		
}

